from flask import Flask, session, request
from functools import wraps
from DBcm import UseDB
app = Flask(__name__)
app.config['db'] = {'host':'127.0.0.1', 'user':'incharge', 'database':'dbexchange', 'password':'iamincharge'}

def check_email(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if request.method == 'POST':
            if '.com' in request.form['email']:
                return func(*args, **kwargs)
            return 'Wrong email'
    return wrapper

def check_password(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if request.method == 'POST':
            if request.form['password'] == request.form['confirm_password']:
                return func(*args, **kwargs)
            return 'Re-check your password'
    return wrapper

def dup_email(func):
    @wraps(func)
    def wrapper(*args, kwargs):
        if request.method == 'POST':
            with UseDB(app.config['db']) as cursor:
                _SQL = '''SELECT email FROM users_info'''
                cursor.execute()
                emails = cursor.fetchall()
                for email in emails:
                    if request.form['email'] in email:
                        return 'Email has been used for another account'
                    return func(*args, **kwargs)
    return wrapper


    