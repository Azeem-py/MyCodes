from flask import Flask, render_template as rt, request, session
from DBcm import UseDB

app = Flask(__name__)
app.config['db'] = {'host':'127.0.0.1', 'user':'incharge', 'database':'dbexchange', 'password':'iamincharge'}

@app.route('/')
def home():
    return rt('index.html')
@app.route('/signup', methods=['POST', 'GET'])
def do_signup():
    if request.method == 'POST':
        try:
            data = (request.form['name'], request.form['email'], request.form['username'], request.form['password'], request.remote_addr, request.user_agent.browser)
            with UseDB(app.config['db']) as cursor:
                if request.form['password'] == request.form['confirm_password']:
                    if '.com' in request.form['email']:
                        _SQL = '''select * from users_info'''
                        cursor.execute(_SQL)
                        emails = cursor.fetchall()
                        if request.form['email'] not in emails:
                            _SQL = '''INSERT INTO users_info Name, email, username, password, IP, browser_string
                                    values(%s, %s, %s, %s, %s, %s)
                                '''
                            cursor.execute(_SQL, data)
                            session['logged_in'] == True
                            return  'Account created successfully' #rt('index.html')
                    return 'Check your email format'
                return 'Re-confirm your password'
        except Exception as err:
            return 'Error: ', err

    return rt('signup.html')

@app.route('/login')
def do_login():
    if request.method == 'POST':
        with UseDB(app.config['db']) as cursor:
            data = (request.form['email'], request.form['password'])
            _SQL = '''SELECT email, password from users_info where email=%s
                    '''
            cursor.execute(_SQL, (data[0],))
            info = cursor.fetchall()
            if info[1] == data[1]:
                return 'You\'re now logged in'
    return rt('login.html')


if __name__ == '__main__':
    app.run(debug=True)